//
//  LoginScreenUIApp.swift
//  LoginScreenUI
//
//  Created by ARUN S S on 04/10/23.
//

import SwiftUI

@main
struct LoginScreenUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
